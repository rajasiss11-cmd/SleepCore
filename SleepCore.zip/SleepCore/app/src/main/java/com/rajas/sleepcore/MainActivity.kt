package com.rajas.sleepcore

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Home screen: the sleep core, Start/Complete sleep, and separate
 * weekly, monthly and all-time sections. The colour theme follows the weekly verdict.
 */
class MainActivity : Activity() {

    private lateinit var store: SleepStore
    private lateinit var scroll: ScrollView
    private val ui = Handler(Looper.getMainLooper())
    private var reactor: ReactorView? = null
    private var topText: TextView? = null
    private var asking = false
    private val dateFmt = SimpleDateFormat("EEE dd MMM  HH:mm", Locale.US)

    private val tick = object : Runnable {
        override fun run() {
            refreshTop()
            ui.postDelayed(this, 1000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        store = SleepStore(this)
        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            isFillViewport = true
        }
        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        render()
        checkForgotten()
        ui.post(tick)
    }

    override fun onPause() {
        ui.removeCallbacks(tick)
        super.onPause()
    }

    // ------------------------------------------------------------- building

    private fun render() {
        val now = System.currentTimeMillis()
        val week = store.week(now)
        val month = store.month(now)
        val all = store.all()
        val v = Verdict.forHours(week.avg)

        scroll.setBackgroundColor(v.bg)
        window.statusBarColor = v.bg
        window.navigationBarColor = v.bg

        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(20), dp(18), dp(36))
        }

        c.addView(tv("☾  SLEEP CORE", 18f, v.accent, bold = true).apply { gravity = Gravity.CENTER }, lp())

        val r = ReactorView(this)
        reactor = r
        c.addView(r, LinearLayout.LayoutParams(dp(250), dp(250)).apply {
            gravity = Gravity.CENTER_HORIZONTAL
            topMargin = dp(10)
        })

        val top = tv("", 13f, v.text).apply { gravity = Gravity.CENTER }
        topText = top
        c.addView(top, lp(8))
        c.addView(tv("WEEKLY VERDICT · ${v.label}", 15f, v.accent, bold = true).apply {
            gravity = Gravity.CENTER
        }, lp(6))

        val active = store.activeStart() > 0
        c.addView(button(if (active) "■  COMPLETE SLEEP" else "☾  START SLEEP", v) { onMainButton() }, lp(16))

        // Weekly section: bars and the last nights, with delete buttons.
        val wc = statsCard("WEEKLY · LAST 7 DAYS", week)
        wc.addView(BarsView(this, week.nights), LinearLayout.LayoutParams(-1, dp(130)).apply { topMargin = dp(14) })
        for (n in week.nights.take(7)) wc.addView(nightRow(n), lp(6))
        c.addView(wc, lp(14))

        c.addView(statsCard("MONTHLY · LAST 30 DAYS", month), lp(14))
        c.addView(statsCard("OVERALL · ALL TIME", all), lp(14))

        scroll.removeAllViews()
        scroll.addView(c)
        refreshTop()
    }

    private fun refreshTop() {
        val now = System.currentTimeMillis()
        val s = store.activeStart()
        val hours = if (s > 0) {
            (now - s) / HOUR_MS.toDouble()
        } else {
            store.nights().firstOrNull()?.hours ?: 0.0
        }
        val v = Verdict.forHours(store.week(now).avg)
        reactor?.set(hours, v.accent)
        topText?.text = when {
            s > 0 -> "ASLEEP SINCE ${clock(s)} · ${fmtHM(hours)}"
            store.nights().isEmpty() -> "No sleep logged yet"
            else -> "LAST NIGHT · ${fmtHM(hours)}"
        }
    }

    private fun statsCard(title: String, s: Stats): LinearLayout {
        val v = Verdict.forHours(s.avg)
        val c = card(v)
        c.addView(tv(title, 12f, v.accent, bold = true), lp())
        val a = s.avg
        if (a == null) {
            c.addView(tv("No nights logged yet.", 16f, v.text), lp(6))
            return c
        }
        c.addView(tv("${fmtHM(a)}  ·  ${v.label}", 22f, v.accent, bold = true), lp(6))
        c.addView(tv("nights ${s.count}   total ${fmtHM(s.total)}", 12f, v.text), lp(4))
        val best = s.best?.hours ?: 0.0
        val worst = s.worst?.hours ?: 0.0
        c.addView(tv("best ${fmtHM(best)}   worst ${fmtHM(worst)}", 12f, v.text), lp(2))
        return c
    }

    private fun nightRow(n: Night): LinearLayout {
        val nv = Verdict.forHours(n.hours)
        return LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(
                tv("${dateFmt.format(Date(n.start))}   ${fmtHM(n.hours)}", 13f, nv.text),
                LinearLayout.LayoutParams(0, -2, 1f)
            )
            addView(tv("✕", 14f, nv.accent, bold = true).apply {
                setPadding(dp(12), dp(6), dp(6), dp(6))
                setOnClickListener { confirmDelete(n) }
            })
        }
    }

    // -------------------------------------------------------------- actions

    private fun onMainButton() {
        val now = System.currentTimeMillis()
        if (store.activeStart() == 0L) {
            store.startSleep(now)
            toast("Sleep started. Good night.")
        } else {
            val n = store.completeSleep(now)
            toast(if (n == null) "Too short or invalid. Not saved." else "Logged ${fmtHM(n.hours)}")
        }
        render()
    }

    /** If Complete was never tapped, ask how long the user slept. */
    private fun checkForgotten() {
        val s = store.activeStart()
        if (s == 0L || asking) return
        if (System.currentTimeMillis() - s < 14 * HOUR_MS) return
        asking = true
        val input = EditText(this).apply {
            hint = "hours slept, e.g. 7.5"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
        }
        AlertDialog.Builder(this)
            .setTitle("You forgot to finish last night")
            .setMessage("You started sleep at ${clock(s)}. How many hours did you sleep?")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                val h = input.text.toString().toDoubleOrNull()
                if (h != null && h in 0.1..20.0) {
                    store.addNight(Night(s, s + (h * HOUR_MS).toLong()))
                }
                store.cancelActive()
                asking = false
                render()
            }
            .setNegativeButton("DISCARD") { _, _ ->
                store.cancelActive()
                asking = false
                render()
            }
            .setOnCancelListener { asking = false }
            .show()
    }

    private fun confirmDelete(n: Night) {
        AlertDialog.Builder(this)
            .setTitle("Delete this night?")
            .setMessage("${dateFmt.format(Date(n.start))} · ${fmtHM(n.hours)}")
            .setPositiveButton("DELETE") { _, _ ->
                store.deleteNight(n.start)
                render()
            }
            .setNegativeButton("KEEP", null)
            .show()
    }

    // -------------------------------------------------------------- helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun lp(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(top) }

    private fun tv(text: CharSequence, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(color)
            typeface = Typeface.create(Typeface.MONOSPACE, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }

    private fun card(v: Verdict): LinearLayout =
        LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(14), dp(16), dp(14))
            background = GradientDrawable().apply {
                setColor(withA(v.accent, 20))
                setStroke(dp(1), withA(v.accent, 120))
                cornerRadius = dp(14).toFloat()
            }
        }

    private fun button(text: String, v: Verdict, onClick: () -> Unit): TextView =
        tv(text, 15f, v.accent, bold = true).apply {
            gravity = Gravity.CENTER
            setPadding(dp(14), dp(16), dp(14), dp(16))
            background = GradientDrawable().apply {
                setColor(withA(v.accent, 36))
                setStroke(dp(2), v.accent)
                cornerRadius = dp(12).toFloat()
            }
            setOnClickListener { onClick() }
        }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()
}
