package com.rajas.sleepcore

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RadialGradient
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import java.text.SimpleDateFormat
import java.util.Locale
import kotlin.math.min
import kotlin.math.sin
import kotlin.random.Random

/** Night-sky backdrop for the intro: twinkling stars and a moon that rises. */
class SkyView(ctx: Context) : View(ctx) {

    private val count = 160
    private val stars = FloatArray(count * 3)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private var t0 = 0L

    private val frame = object : Runnable {
        override fun run() {
            invalidate()
            postOnAnimation(this)
        }
    }

    init {
        val rnd = Random(42)
        for (i in 0 until count) {
            stars[i * 3] = rnd.nextFloat()
            stars[i * 3 + 1] = rnd.nextFloat()
            stars[i * 3 + 2] = rnd.nextFloat() * 6.28f
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        t0 = System.currentTimeMillis()
        postOnAnimation(frame)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(frame)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val t = (System.currentTimeMillis() - t0) / 1000f
        val w = width.toFloat()
        val h = height.toFloat()

        for (i in 0 until count) {
            val x = stars[i * 3] * w
            val y = stars[i * 3 + 1] * h
            val ph = stars[i * 3 + 2]
            p.style = Paint.Style.FILL
            p.color = 0xFFFFFFFF.toInt()
            p.alpha = (90 + 165 * (0.5f + 0.5f * sin(t * 1.7f + ph))).toInt()
            c.drawCircle(x, y, 1.2f + (ph % 1f) * 1.4f, p)
        }

        // moon rising over 3 seconds
        val prog = (t / 3.2f).coerceIn(0f, 1f)
        val ease = 1f - (1f - prog) * (1f - prog)
        val mx = w * 0.78f
        val my = h * 1.05f - h * 0.85f * ease
        val mr = min(w, h) * 0.11f
        p.alpha = 255
        p.shader = RadialGradient(mx, my, mr * 3.2f, 0x557C9CFF, 0x007C9CFF, Shader.TileMode.CLAMP)
        c.drawCircle(mx, my, mr * 3.2f, p)
        p.shader = null
        p.color = 0xFFE8EAF6.toInt()
        c.drawCircle(mx, my, mr, p)
        p.color = 0x33000000
        c.drawCircle(mx - mr * 0.3f, my - mr * 0.2f, mr * 0.22f, p)
        c.drawCircle(mx + mr * 0.25f, my + mr * 0.3f, mr * 0.15f, p)
    }
}

/** Seven bars, one per recent night, each coloured by that night's verdict. */
class BarsView(ctx: Context, private val data: List<Night>) : View(ctx) {

    private val dp = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val lbl = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = 10 * dp
        color = 0xAAFFFFFF.toInt()
        textAlign = Paint.Align.CENTER
        typeface = Typeface.MONOSPACE
    }
    private val dayFmt = SimpleDateFormat("EEE", Locale.US)

    override fun onDraw(c: Canvas) {
        val list = data.sortedBy { it.start }.takeLast(7)
        val n = 7
        val slot = width / n.toFloat()
        val base = height - 18 * dp
        val maxH = base - 6 * dp
        for (i in 0 until n) {
            val idx = i - (n - list.size)
            val cx = slot * (i + 0.5f)
            val barW = slot * 0.55f
            if (idx < 0) {
                p.color = 0x22FFFFFF
                c.drawRoundRect(RectF(cx - barW / 2, base - 4 * dp, cx + barW / 2, base), 4 * dp, 4 * dp, p)
                continue
            }
            val night = list[idx]
            val v = Verdict.forHours(night.hours)
            val bh = (night.hours / 10.0).coerceIn(0.0, 1.0).toFloat() * maxH
            p.color = v.accent
            c.drawRoundRect(RectF(cx - barW / 2, base - bh, cx + barW / 2, base), 6 * dp, 6 * dp, p)
            c.drawText(dayFmt.format(java.util.Date(night.start)), cx, height - 4 * dp, lbl)
        }
    }
}
