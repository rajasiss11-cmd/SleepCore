package com.rajas.sleepcore

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView

/** Animated intro: a night sky, a rising moon, and three short lines before ENTER. */
class IntroActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val sp = getSharedPreferences("sleep", MODE_PRIVATE)
        if (sp.getBoolean("introSeen", false)) {
            startActivity(Intent(this, MainActivity::class.java))
            finish()
            return
        }

        val dp = resources.displayMetrics.density
        val bgColor = 0xFF02040A.toInt()
        window.statusBarColor = bgColor
        window.navigationBarColor = bgColor

        val root = FrameLayout(this).apply { setBackgroundColor(bgColor) }
        root.addView(SkyView(this), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding((28 * dp).toInt(), (24 * dp).toInt(), (28 * dp).toInt(), (24 * dp).toInt())
        }
        root.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        val title = TextView(this).apply {
            text = "SLEEP CORE"
            textSize = 34f
            setTextColor(0xFFE8EAF6.toInt())
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            gravity = Gravity.CENTER
            setShadowLayer(24f, 0f, 0f, 0xFF7C9CFF.toInt())
            alpha = 0f
        }
        col.addView(title)

        val lines = listOf(
            "Tap START when you go to bed.",
            "Tap COMPLETE when you wake up.",
            "Fill the core. Don't overload it."
        )
        val lineViews = lines.map { line ->
            TextView(this).apply {
                text = line
                textSize = 15f
                setTextColor(0xFFB0BEC5.toInt())
                gravity = Gravity.CENTER
                setPadding(0, (8 * dp).toInt(), 0, 0)
                alpha = 0f
            }.also { col.addView(it) }
        }

        val btn = TextView(this).apply {
            text = "ENTER"
            gravity = Gravity.CENTER
            textSize = 16f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            setTextColor(0xFFFFFFFF.toInt())
            setPadding((40 * dp).toInt(), (14 * dp).toInt(), (40 * dp).toInt(), (14 * dp).toInt())
            background = GradientDrawable().apply {
                setColor(0x552C3E8F)
                setStroke((2 * dp).toInt(), 0xFF7C9CFF.toInt())
                cornerRadius = 12 * dp
            }
            alpha = 0f
            setOnClickListener {
                sp.edit().putBoolean("introSeen", true).apply()
                startActivity(Intent(this@IntroActivity, MainActivity::class.java))
                finish()
            }
        }
        col.addView(btn, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply {
            topMargin = (28 * dp).toInt()
        })

        setContentView(root)

        title.animate().alpha(1f).setStartDelay(900).setDuration(1200).start()
        lineViews.forEachIndexed { i, v ->
            v.animate().alpha(1f).setStartDelay(2000L + i * 700L).setDuration(800).start()
        }
        btn.animate().alpha(1f).setStartDelay(4400).setDuration(700).start()
    }
}
