package com.rajas.sleepcore

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RadialGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.view.View
import kotlin.math.max
import kotlin.math.min

/**
 * Sleep core. Fills as you sleep (full at 8.5 h).
 *  - past 6 h   : spins faster
 *  - past 8.5 h : shakes, spins out of control, and overflows in gold
 */
class ReactorView(ctx: Context) : View(ctx) {

    private var hours = 0.0
    private var color = 0xFF00E676.toInt()
    private var angle = 0f
    private var lastNs = 0L
    private val dp = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val rnd = java.util.Random()
    private val gold = 0xFFFFD700.toInt()

    private val frame = object : Runnable {
        override fun run() {
            invalidate()
            postOnAnimation(this)
        }
    }

    fun set(h: Double, col: Int) {
        hours = h
        color = col
        invalidate()
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        postOnAnimation(frame)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(frame)
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else min(0.05f, (now - lastNs) / 1e9f)
        lastNs = now

        val over = max(0.0, hours - 8.5)
        val overloaded = hours > 8.5
        val speed = when {
            hours <= 6.0 -> 25f + (hours * 5).toFloat()
            hours <= 8.5 -> 55f + ((hours - 6.0) * 70).toFloat()
            else -> 230f + (over * 350).toFloat()
        }
        angle = (angle + speed * dt) % 360f

        val shake = if (overloaded) (3 + over * 10).toFloat() * dp else 0f
        val cx = width / 2f + (rnd.nextFloat() - 0.5f) * 2 * shake
        val cy = height / 2f + (rnd.nextFloat() - 0.5f) * 2 * shake
        val r = min(width, height) * 0.36f
        val fill = (hours / 8.5).coerceIn(0.0, 1.0).toFloat()
        val col = if (overloaded) gold else color

        // overflow glow spilling past the rim
        if (overloaded) {
            val spill = r * (1.12f + min(over.toFloat(), 2f) * 0.22f)
            p.style = Paint.Style.FILL
            p.shader = RadialGradient(cx, cy, spill, withA(gold, 170), withA(gold, 0), Shader.TileMode.CLAMP)
            c.drawCircle(cx, cy, spill, p)
            p.shader = null
        }

        // soft glow
        p.style = Paint.Style.FILL
        p.shader = RadialGradient(cx, cy, r * 1.3f, withA(col, 90), withA(col, 0), Shader.TileMode.CLAMP)
        c.drawCircle(cx, cy, r * 1.3f, p)
        p.shader = null

        // core background
        p.color = withA(col, 40)
        c.drawCircle(cx, cy, r, p)

        // liquid level
        c.save()
        val clip = Path().apply { addCircle(cx, cy, r, Path.Direction.CW) }
        c.clipPath(clip)
        val levelY = cy + r - fill * 2 * r
        p.shader = LinearGradient(0f, levelY, 0f, cy + r, withA(col, 255), withA(col, 110), Shader.TileMode.CLAMP)
        c.drawRect(cx - r, levelY, cx + r, cy + r, p)
        p.shader = null
        c.restore()

        // rings
        p.style = Paint.Style.STROKE
        p.strokeCap = Paint.Cap.ROUND
        p.color = withA(col, 200)
        p.strokeWidth = 4 * dp
        c.drawCircle(cx, cy, r * 1.08f, p)

        p.strokeWidth = 6 * dp
        for (k in 0 until 3) {
            c.drawArc(cx - r * 1.2f, cy - r * 1.2f, cx + r * 1.2f, cy + r * 1.2f, angle + k * 120f, 60f, false, p)
        }

        p.strokeWidth = 2 * dp
        p.color = withA(col, 150)
        p.pathEffect = DashPathEffect(floatArrayOf(10 * dp, 8 * dp), 0f)
        c.save()
        c.rotate(-angle * 1.6f, cx, cy)
        c.drawCircle(cx, cy, r * 1.32f, p)
        c.restore()
        p.pathEffect = null

        // text
        p.style = Paint.Style.FILL
        p.strokeCap = Paint.Cap.BUTTON
        p.textAlign = Paint.Align.CENTER
        p.typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        p.color = Color.WHITE
        p.textSize = r * 0.34f
        c.drawText(if (hours <= 0.0) "--" else fmtHM(hours), cx, cy + r * 0.1f, p)
        p.textSize = r * 0.13f
        p.color = col
        val tag = if (overloaded) "OVERLOAD" else "CORE ${(fill * 100).toInt()}%"
        c.drawText(tag, cx, cy + r * 0.42f, p)
    }
}
