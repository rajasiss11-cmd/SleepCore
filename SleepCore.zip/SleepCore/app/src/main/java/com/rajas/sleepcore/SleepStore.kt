package com.rajas.sleepcore

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

const val HOUR_MS = 3_600_000L
const val DAY_MS = 24L * HOUR_MS

/** One completed night of sleep. [start] doubles as its unique id. */
data class Night(val start: Long, val end: Long) {
    val hours: Double get() = (end - start) / HOUR_MS.toDouble()
}

/**
 * The verdict decides the whole app's colour theme. It uses the average of the
 * nights logged in the last 7 days. Colours are fixed, the user cannot change them.
 */
enum class Verdict(val label: String, val accent: Int, val bg: Int, val text: Int) {
    NONE("NO DATA", 0xFF7A8794.toInt(), 0xFF0B0C10.toInt(), 0xFFB0BEC5.toInt()),
    BLACK("VERY BAD", 0xFFBDBDBD.toInt(), 0xFF000000.toInt(), 0xFFE0E0E0.toInt()),
    RED("BAD", 0xFFFF3B3B.toInt(), 0xFF120303.toInt(), 0xFFFFCDD2.toInt()),
    YELLOW("NOT SO GOOD", 0xFFFFD600.toInt(), 0xFF110E02.toInt(), 0xFFFFF59D.toInt()),
    GREEN("GOOD", 0xFF00E676.toInt(), 0xFF02100A.toInt(), 0xFFB9F6CA.toInt()),
    GOLD("EXCELLENT", 0xFFFFD700.toInt(), 0xFF120E01.toInt(), 0xFFFFE082.toInt());

    companion object {
        fun forHours(avg: Double?): Verdict = when {
            avg == null -> NONE
            avg >= 8.0 -> GOLD
            avg >= 7.0 -> GREEN
            avg >= 5.5 -> YELLOW
            avg >= 4.0 -> RED
            else -> BLACK
        }
    }
}

/** Summary numbers for a list of nights. */
class Stats(val nights: List<Night>) {
    val count = nights.size
    val total = nights.sumOf { it.hours }
    val avg: Double? = if (nights.isEmpty()) null else total / nights.size
    val best: Night? = nights.maxByOrNull { it.hours }
    val worst: Night? = nights.minByOrNull { it.hours }
}

class SleepStore(ctx: Context) {

    private val sp = ctx.applicationContext.getSharedPreferences("sleep", Context.MODE_PRIVATE)

    fun nights(): List<Night> {
        val out = ArrayList<Night>()
        try {
            val arr = JSONArray(sp.getString("nights", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Night(o.getLong("s"), o.getLong("e")))
            }
        } catch (e: Exception) {
            // corrupt data: start fresh
        }
        return out.sortedByDescending { it.start }
    }

    private fun write(list: List<Night>) {
        val arr = JSONArray()
        for (n in list) arr.put(JSONObject().put("s", n.start).put("e", n.end))
        sp.edit().putString("nights", arr.toString()).apply()
    }

    /** 0 when no sleep is in progress. */
    fun activeStart(): Long = sp.getLong("active", 0L)

    fun startSleep(now: Long) {
        sp.edit().putLong("active", now).apply()
    }

    fun cancelActive() {
        sp.edit().putLong("active", 0L).apply()
    }

    /** Ends the sleep in progress. Returns the saved night, or null if it was too short or too long. */
    fun completeSleep(now: Long): Night? {
        val s = activeStart()
        if (s == 0L) return null
        cancelActive()
        val dur = now - s
        if (dur < 10 * 60_000L || dur > 24 * HOUR_MS) return null
        val n = Night(s, now)
        addNight(n)
        return n
    }

    fun addNight(n: Night) {
        write(nights().filter { it.start != n.start } + n)
    }

    fun deleteNight(start: Long) {
        write(nights().filter { it.start != start })
    }

    fun since(cutoff: Long): Stats = Stats(nights().filter { it.start >= cutoff })
    fun all(): Stats = Stats(nights())
    fun week(now: Long): Stats = since(now - 7 * DAY_MS)
    fun month(now: Long): Stats = since(now - 30 * DAY_MS)
}

fun fmtHM(h: Double): String {
    val m = Math.round(h * 60).toInt().coerceAtLeast(0)
    return "${m / 60}h ${(m % 60).toString().padStart(2, '0')}m"
}

fun clock(ms: Long): String = SimpleDateFormat("HH:mm", Locale.US).format(Date(ms))

fun withA(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)
