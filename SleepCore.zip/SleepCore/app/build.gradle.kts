plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.rajas.sleepcore"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.rajas.sleepcore"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    // Fixed debug key so each new APK installs over the previous one.
    signingConfigs {
        getByName("debug") {
            storeFile = file("sleep-debug.keystore")
            storePassword = "android"
            keyAlias = "sleepdebug"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}
